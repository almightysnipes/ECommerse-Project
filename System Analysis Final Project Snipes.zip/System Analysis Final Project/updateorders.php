<p>Update Order Form</p>

<?php
    session_start();
require_once "myfunctions.php";
myconnect();

   $orderid = $_REQUEST['orderid'];
   $Actual_delivery_date = $_REQUEST['Actual_delivery_date'];

   echo("order ID is ". $orderid);
   echo("Actual delivery date is ".$Actual_delivery_date);


    $result = mysql_query("UPDATE `orders` SET `productid` = '$productid' WHERE `orderid` = '$orderid'");

?>