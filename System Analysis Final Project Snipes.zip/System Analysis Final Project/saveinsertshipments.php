<html>

<body>

 

 

<?php

   // saving script

   

     $dbcnx = @mysql_connect("localhost", "quickme1_4211",
   "csci4211");
 

if (!$dbcnx) { 

    echo( "<p>Unable to connect to the " . 

          "database server at this time.</p>" 

   ); 

    exit(); 

   } 

 

   

 

// Select the Registration database 

  if (! @mysql_select_db("quickme1_4211") ) {

    echo( "<p>Unable to locate the registration " . 

          "database at this time.</p>" ); 

    exit(); 

  } 

   

   // get the variables from the URL request string

   $shipmentid = $_REQUEST['shipmentid'];

   $orderid = $_REQUEST['orderid'];

   $start_shipment_date = $_REQUEST['start_shipment_date'];

   $delivery_date = $_REQUEST['delivery_date'];

    $delivery_address = $_REQUEST['delivery_address'];

    $Cost = $_REQUEST['Cost'];

    $shipment_contact = $_REQUEST['shipment_contact'];

    $shipment_phone = $_REQUEST['shipment_phone'];

    $shipment_email = $_REQUEST['shipment_email'];

    $shipment_type = $_REQUEST['shipment_type'];

    

   echo("$shipmentid<br>");

   echo("$orderid<br>");

   

      $query = "INSERT INTO `shipments` ( `shipmentid`,`orderid`, `start_shipment_date`, `delivery_date`, `delivery_address`, `Cost`, `shipment_contact`, `shipment_phone`, `shipment_email`, `shipment_type` )

         VALUES ('$shipmentd','$orderid', '$start_shipment_date', '$delivery_date', '$delivery_address', '$Cost', '$shipment_contact', '$shipment_phone', '$shipment_email', '$shipment_type')";

 

 

   // save the info to the database

   $results = mysql_query( $query );

 

   // print out the results

   if( $results )

   {

      echo( "Successfully saved the entry." );

   }

   else

   {

      echo( "Trouble saving information to the database: ");

   }

   

?>

 

</body>

</html>
