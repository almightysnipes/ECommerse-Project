
<?php
require_once "myfunctions.php";
myconnect();
    

   $customerid = $_REQUEST['customerid'];

echo "customerid = $customerid";


    $result = mysql_query("DELETE FROM customer WHERE customerid = '$customerid'");
$count=mysql_affected_rows();
If ($count==1)
echo "Succesfully deleted";
else
{ 
echo "error deleting";
exit();
}

?>