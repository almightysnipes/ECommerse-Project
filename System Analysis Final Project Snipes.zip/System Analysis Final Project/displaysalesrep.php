<html>
<body>


Results of Salesreps Database<br><br>

<?php
require_once "myfunctions.php";
myconnect();
  
   // retrieve all the rows from the database
   $query = "SELECT * FROM `salesrep` ORDER BY `lastname`";
   
   $results = mysql_query( $query );

   // print out the results
   if( $results )
   {
      while( $student = mysql_fetch_object( $results ) )
      {
         // print out the info
         $salesrepid = $salesrep -> salesrepid;
         $lastname = $salesrep -> lastname;
         $firstname = $salesrep -> firstname;
         $address = $salesrep ->address;
         
         echo( "$salesrepid <br>, $lastname<br>, $firstname<br>, $address<br><br><br>" );
      }
   }
   else
   {
      echo( "Trouble getting students from database: ");
   }
   
?>

</body>
</html>
