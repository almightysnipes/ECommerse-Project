<html>

<body>
 

<?php

session_start();
require_once "myfunctions.php";
myconnect();



   $studentid = $_REQUEST['salesrepid'];

   

$sql = "SELECT * FROM `salesrep` WHERE `salesrepid` LIKE '%$salesrepid'";
$queryResource = mysql_query($sql);

// Fetch rows from MySQL one at a time
while ($row = mysql_fetch_array($queryResource, MYSQL_ASSOC)) {
echo 'salesrepid: ' . $row['salesrepid'] . '<br />';
echo 'Last Name: ' . $row['lastname'] . '<br />';
echo 'First Name: ' . $row['firstname'] . '<br />';
echo 'Address: ' . $row['address'] . '<br />';
echo 'Phone: ' . $row['phone'] . '<br />';
echo 'Email: ' . $row['email'] . '<br />';

}






?>
</html>