<html>

<body>

 

 

<?php

   // saving script

   

     $dbcnx = @mysql_connect("localhost", "quickme1_4211",
   "csci4211");
 

if (!$dbcnx) { 

    echo( "<p>Unable to connect to the " . 

          "database server at this time.</p>" 

   ); 

    exit(); 

   } 

 

   

 

// Select the Registration database 

  if (! @mysql_select_db("quickme1_4211") ) {

    echo( "<p>Unable to locate the registration " . 

          "database at this time.</p>" ); 

    exit(); 

  } 

   

   // get the variables from the URL request string

   $salesrepid = $_REQUEST['salesrepid'];

   $lastname = $_REQUEST['lastname'];

   $firstname = $_REQUEST['firstname'];

   $address = $_REQUEST['address'];

    $phone = $_REQUEST['phone'];

    $email = $_REQUEST['email'];

    

   echo("$salesrepid<br>");

   echo("$lastname<br>");

   

      $query = "INSERT INTO `salesrep` ( `salesrepid`,`lastname`, `firstname`, `address`, `phone`, `email` )

         VALUES ('$salesrepid','$lastname', '$firstname', '$address', '$phone', '$email')";

 

 

   // save the info to the database

   $results = mysql_query( $query );

 

   // print out the results

   if( $results )

   {

      echo( "Successfully saved the entry." );

   }

   else

   {

      echo( "Trouble saving information to the database: ");

   }

   

?>

 

</body>

</html>
