
<?php
require_once "myfunctions.php";
myconnect();
    

   $orderid = $_REQUEST['orderid'];

echo "orderid = $orderid";


    $result = mysql_query("DELETE FROM orders WHERE orderid = '$orderid'");
$count=mysql_affected_rows();
If ($count==1)
echo "Succesfully deleted";
else
{ 
echo "error deleting";
exit();
}

?>