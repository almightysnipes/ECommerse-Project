<?php
session_start();
?>


<!DOCTYPE html>
<!-- saved from url=(0046)file:///C:/Users/rowor/Downloads/login(1).html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="./login_files/font-awesome.min.css">
<link rel="stylesheet" href="./login_files/w3.css">


<style>
form {
    border: 3px solid #f1f1f1;
}

input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}

.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
}

img.avatar {
    width: 40%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}
</style>
</head><body>
<!-- Navigation -->
<nav>
  <ul class="w3-navbar w3-black">
    <li><a href="javascript:void(0)">Home</a></li>
    <li><a href="javascript:void(0)">About the Project</a></li>
    <li><a href="javascript:void(0)">Services</a></li>
    <li><a href="javascript:void(0)">Contact</a></li>
  </ul>
</nav>

<!-- Content Starts-->
<div class="imgcontainer">
  
  </div>
<center><h2>Ecommerse Customer Form</h2>

<form name="save customer" method="post" action="saveinsertcustomer.php">
  
  <div class="container">
    <label><b>Customer ID</b></label>
    <input type="text" placeholder="Enter Customer ID" name="customerid" required="">

    <label><b>Last Name</b></label>
    <input type="text" placeholder="Enter Last Name" name="lastname" required="">

 <label><b>First Name</b></label>
    <input type="text" placeholder="Enter First Name" name="firstname" required="">

<label><b>Address</b></label>
    <input type="text" placeholder="Enter Address" name="address" required="">
        
  <label><b>Phone</b></label>
    <input type="text" placeholder="Enter Phone" name="phone" required="">
              
  <label><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required="">
  
            
    <button type="submit">submit</button>
    
  </div>
  <div class="container" style="background-color:#f1f1f1">
    
   <br>
   
  </div>
</form>
</center>
<br>


<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-black w3-xlarge">
  <a href="file:///C:/Users/rowor/Downloads/login(1).html#"><i class="fa fa-facebook-official"></i></a>
  <a href="file:///C:/Users/rowor/Downloads/login(1).html#"><i class="fa fa-pinterest-p"></i></a>
  <a href="file:///C:/Users/rowor/Downloads/login(1).html#"><i class="fa fa-twitter"></i></a>
  <a href="file:///C:/Users/rowor/Downloads/login(1).html#"><i class="fa fa-flickr"></i></a>
  <a href="file:///C:/Users/rowor/Downloads/login(1).html#"><i class="fa fa-linkedin"></i></a>
  <p class="w3-medium">
  (c) Copyright CSCI4211 Project, 2021.
  </p>
</footer>



</body></html>