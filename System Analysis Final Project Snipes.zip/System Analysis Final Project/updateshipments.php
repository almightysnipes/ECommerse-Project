<p>Update Shipment Forms</p>

<?php
    session_start();
require_once "myfunctions.php";
myconnect();

   $shipmentid = $_REQUEST['shipmentid'];
   $delivery_date = $_REQUEST['delivery_date'];

   echo("shipment ID is ". $shipmentid);
   echo("Delivery date is ".$delivery_date);


    $result = mysql_query("UPDATE `shipments` SET `delivery_address` = '$delivery_address' WHERE `shipmentid` = '$shipmentid'");

?>