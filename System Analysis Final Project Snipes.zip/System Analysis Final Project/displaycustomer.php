<html>
<body>


Results of Customer Database<br><br>

<?php
require_once "myfunctions.php";
myconnect();
  
   // retrieve all the rows from the database
   $query = "SELECT * FROM `customer` ORDER BY `lastname`";
   
   $results = mysql_query( $query );

   // print out the results
   if( $results )
   {
      while( $customer = mysql_fetch_object( $results ) )
      {
         // print out the info
         $customerid = $customer -> customerid;
         $lastname = $customer -> lastname;
         $firstname = $customer -> firstname;
         $address = $customer ->address;
         
         echo( "$customerid <br>, $lastname<br>, $firstname<br>, $address<br><br><br>" );
      }
   }
   else
   {
      echo( "Trouble getting students from database: ");
   }
   
?>

</body>
</html>
