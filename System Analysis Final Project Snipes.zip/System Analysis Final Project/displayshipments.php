<html>
<body>


Results of Shipment Database<br><br>

<?php
require_once "myfunctions.php";
myconnect();
  
   // retrieve all the rows from the database
   $query = "SELECT * FROM `shipments` ORDER BY `orderid`";
   
   $results = mysql_query( $query );

   // print out the results
   if( $results )
   {
      while( $shipments = mysql_fetch_object( $results ) )
      {
         // print out the info
         $shipmentid = $shipments -> shipmentid;
         $orderid = $shipments -> orderid;
         $delivery_date = $shipments -> delivery_date;
         $delivery_address = $shipments -> delivery_address;
         
         echo( "$shipmentid <br>, $orderid<br>, $delivery_date<br>, $delivery_address<br><br><br>" );
      }
   }
   else
   {
      echo( "Trouble getting shipments from database: ");
   }
   
?>

</body>
</html>
