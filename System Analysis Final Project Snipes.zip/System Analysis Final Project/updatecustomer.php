<p>Update Customer Form</p>

<?php
    session_start();
require_once "myfunctions.php";
myconnect();

   $customerid = $_REQUEST['customerid'];
   $address = $_REQUEST['address'];

   echo("customer ID is ". $customerid);
   echo("address is ".$address);


    $result = mysql_query("UPDATE `customer` SET `address` = '$address' WHERE `customerid` = '$customerid'");

?>