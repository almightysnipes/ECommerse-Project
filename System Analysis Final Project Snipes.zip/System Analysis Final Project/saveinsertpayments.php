html>

<body>

 

 

<?php

   // saving script

   

     $dbcnx = @mysql_connect("localhost", "quickme1_4211",
   "csci4211");
 

if (!$dbcnx) { 

    echo( "<p>Unable to connect to the " . 

          "database server at this time.</p>" 

   ); 

    exit(); 

   } 

 

   

 

// Select the Registration database 

  if (! @mysql_select_db("quickme1_4211") ) {

    echo( "<p>Unable to locate the registration " . 

          "database at this time.</p>" ); 

    exit(); 

  } 

   

   // get the variables from the URL request string

   $paymentid = $_REQUEST['paymentid'];

   $payment_date = $_REQUEST['payment_date'];

   $customerid = $_REQUEST['customerid'];

   $orderid = $_REQUEST['orderid'];

    $price = $_REQUEST['price'];

    $shipmentid = $_REQUEST['shipmentid'];

    $taxation = $_REQUEST['taxation'];

    $Payment_method = $_REQUEST['Payment_method'];

    $total_price = $_REQUEST['total_price'];

    $payment_made = $_REQUEST['payment_made'];

    $recipt_number = $_REQUEST['recipt_number'];

    

   echo("$paymentid<br>");

   echo("$payment_date<br>");

   

      $query = "INSERT INTO `payments` ( `paymentid`,`payment_date`, `customerid`, `orderid`, `price`, `shipmentid`, `taxation`, `Payment_method`, `total_price`, `payment_made`, `recipt_number` )

         VALUES ('$paymentid','$payment_date', '$customerid', '$orderid', '$price', '$shipmentid', '$taxation', '$Payment_method', '$total_price', '$payment_made?', '$recipt_number')";

 

 

   // save the info to the database

   $results = mysql_query( $query );

 

   // print out the results

   if( $results )

   {

      echo( "Successfully saved the entry." );

   }

   else

   {

      echo( "Trouble saving information to the database: ");

   }

   

?>

 

</body>

</html>
