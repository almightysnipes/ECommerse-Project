
<?php
require_once "myfunctions.php";
myconnect();
    

   $salesrepid = $_REQUEST['salesrepid'];

echo "salesrepid = $salesrepid";


    $result = mysql_query("DELETE FROM salesrep WHERE salesrepid = '$salesrepid'");
$count=mysql_affected_rows();
If ($count==1)
echo "Succesfully deleted";
else
{ 
echo "error deleting";
exit();
}

?>