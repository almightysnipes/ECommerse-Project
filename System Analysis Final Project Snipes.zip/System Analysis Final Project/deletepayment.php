
<?php
require_once "myfunctions.php";
myconnect();
    

   $studentid = $_REQUEST['paymentid'];

echo "paymentid = $paymentid";


    $result = mysql_query("DELETE FROM payment WHERE paymentid = '$paymentid'");
$count=mysql_affected_rows();
If ($count==1)
echo "Succesfully deleted";
else
{ 
echo "error deleting";
exit();
}

?>