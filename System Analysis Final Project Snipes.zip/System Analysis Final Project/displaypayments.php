<html>
<body>


Results of Payments Database<br><br>

<?php
require_once "myfunctions.php";
myconnect();
  
   // retrieve all the rows from the database
   $query = "SELECT * FROM `payments` ORDER BY `customerid`";
   
   $results = mysql_query( $query );

   // print out the results
   if( $results )
   {
      while( $payments = mysql_fetch_object( $results ) )
      {
         // print out the info
         $paymentid = $payments -> paymentid;
         $customerid = $payments -> customerid;
         $total_price = $payments -> total_price;
         $recipt_number = $payments -> recipt_number;
         
         echo( "$paymentid <br>, $customerid<br>, $total_price<br>, $recipt_number<br><br><br>" );
      }
   }
   else
   {
      echo( "Trouble getting payments from database: ");
   }
   
?>

</body>
</html>
