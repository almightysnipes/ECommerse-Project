
<?php
require_once "myfunctions.php";
myconnect();
    

   $productid = $_REQUEST['productid'];

echo "productid = $productid";


    $result = mysql_query("DELETE FROM product WHERE productid = '$productid'");
$count=mysql_affected_rows();
If ($count==1)
echo "Succesfully deleted";
else
{ 
echo "error deleting";
exit();
}

?>