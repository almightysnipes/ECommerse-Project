<html>

<body>
 

<?php

session_start();
require_once "myfunctions.php";
myconnect();



   $studentid = $_REQUEST['productid'];

   

$sql = "SELECT * FROM `productid` WHERE `productid` LIKE '%$productid'";
$queryResource = mysql_query($sql);

// Fetch rows from MySQL one at a time
while ($row = mysql_fetch_array($queryResource, MYSQL_ASSOC)) {
echo 'productid: ' . $row['productid'] . '<br />';
echo 'Product Name: ' . $row['productname'] . '<br />';
echo 'Product Description: ' . $row['productdescription'] . '<br />';
echo 'Image: ' . $row['image'] . '<br />';
echo 'Quantity In Stock: ' . $row['Quantity_in_stock'] . '<br />';
echo 'Price: ' . $row['price'] . '<br />';
echo 'Code: ' . $row['code'] . '<br />';


}






?>
</html>
