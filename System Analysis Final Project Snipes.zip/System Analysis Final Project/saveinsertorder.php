html>

<body>

 

 

<?php

   // saving script

   

     $dbcnx = @mysql_connect("localhost", "quickme1_4211",
   "csci4211");
 

if (!$dbcnx) { 

    echo( "<p>Unable to connect to the " . 

          "database server at this time.</p>" 

   ); 

    exit(); 

   } 

 

   

 

// Select the Registration database 

  if (! @mysql_select_db("quickme1_4211") ) {

    echo( "<p>Unable to locate the registration " . 

          "database at this time.</p>" ); 

    exit(); 

  } 

   

   // get the variables from the URL request string

   $orderid = $_REQUEST['orderid'];

   $customerid = $_REQUEST['customerid'];

   $salesrepid = $_REQUEST['salesrepid'];

   $productid = $_REQUEST['productid'];

    $quantity = $_REQUEST['quantity'];

    $price = $_REQUEST['price'];

    $date = $_REQUEST['date'];

    $expected_delivery_date = $_REQUEST['expected_delivery_date'];

    $Actual_delivery_date = $_REQUEST['Actual_delivery_date'];

    $Delivery_type = $_REQUEST['Delivery_type'];

    $Name_f_Recipient = $_REQUEST['Name_f_Recipient'];

    

   echo("$orderid<br>");

   echo("$Actual_delivery_date<br>");

   

      $query = "INSERT INTO `orders` ( `orderid`,`customerid`, `salesrepid`, `productid`, `quantity`, `price`, `date`, `expected_delivery_date`, `Actual_delivery_date`, `Delivery_date`, `Name_f_Recipient` )

         VALUES ('$orderid','$customerid', '$salesrepid', '$productid', '$quantity', '$price', '$date', '$expected_delivery_date', '$Actual_delivery_date', '$Delivery_date', '$Name_f_Recipient')";

 

 

   // save the info to the database

   $results = mysql_query( $query );

 

   // print out the results

   if( $results )

   {

      echo( "Successfully saved the entry." );

   }

   else

   {

      echo( "Trouble saving information to the database: ");

   }

   

?>

 

</body>

</html>
