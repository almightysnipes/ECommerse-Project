 <?php
session_start();
require_once "myfunctions.php";
myconnect();
$userid = $_REQUEST['userid'];
$password = $_REQUEST['password1'];
$password2=$_REQUEST['password2'];


If ($password!=$password2)
   {
    echo("<center><br><br><span style='color:#000000;font-size:14pt; font-family: arial'><buttonred>
<a href=\"resetpassword.html\"  target=\"_top\" data-role=\"button\" data-theme=\"e\" data-inline=\"true\">Passwords not the same!, Click here to change passwordin</a></buttonred>
</span></center>");
        exit(); 
    }

echo "userid ". $userid;
echo "password". $password;

$sql = "UPDATE login_tbl SET password='$password' WHERE userid='$userid'";
$r = mysql_query($sql); 
$count=mysql_affected_rows();
echo("$count\n");


if($count==1){ 
  echo "Record updated successfully";
}
else {
 echo "Error updating record: ";
}
//}
?>

