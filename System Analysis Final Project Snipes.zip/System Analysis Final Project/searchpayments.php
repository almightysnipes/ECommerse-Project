<html>

<body>
 

<?php

session_start();
require_once "myfunctions.php";
myconnect();



   $paymentid = $_REQUEST['paymentid'];

   

$sql = "SELECT * FROM `payments` WHERE `paymentid` LIKE '%$paymentid'";
$queryResource = mysql_query($sql);

// Fetch rows from MySQL one at a time
while ($row = mysql_fetch_array($queryResource, MYSQL_ASSOC)) {
echo 'paymentid: ' . $row['paymentid'] . '<br />';
echo 'Payment Date: ' . $row['payment_date'] . '<br />';
echo 'customerid: ' . $row['customerid'] . '<br />';
echo 'orderid: ' . $row['orderid'] . '<br />';
echo 'Price: ' . $row['price'] . '<br />';
echo 'shipmentid: ' . $row['shipmentid'] . '<br />';
echo 'Taxation: ' . $row['taxation'] . '<br />';
echo 'Payment Method: ' . $row['Payment_method'] . '<br />';
echo 'Total Price: ' . $row['total_price'] . '<br />';
echo 'Payment Made: ' . $row['payment_made'] . '<br />';
echo 'Receipt Number: ' . $row['recipt_number'] . '<br />';

}






?>
</html>
