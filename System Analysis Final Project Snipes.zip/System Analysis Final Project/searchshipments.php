<html>

<body>
 

<?php

session_start();
require_once "myfunctions.php";
myconnect();



   $shipmentid = $_REQUEST['shipmentid'];

   

$sql = "SELECT * FROM `shipments` WHERE `shipmentid` LIKE '%$shipmentid'";
$queryResource = mysql_query($sql);

// Fetch rows from MySQL one at a time
while ($row = mysql_fetch_array($queryResource, MYSQL_ASSOC)) {
echo 'shipmentid: ' . $row['shipmentid'] . '<br />';
echo 'orderid: ' . $row['orderid'] . '<br />';
echo 'Start Shipment Date: ' . $row['start_shipment_date'] . '<br />';
echo 'Delivery Date: ' . $row['delivery_date'] . '<br />';
echo 'Delivery Address: ' . $row['delivery_address'] . '<br />';
echo 'Cost: ' . $row['Cost'] . '<br />';
echo 'Shipment Contact: ' . $row['shipment_contact'] . '<br />';
echo 'Shipment Phone: ' . $row['shipment_phone'] . '<br />';
echo 'Shipment Email: ' . $row['shipment_email'] . '<br />';
echo 'Shipment Type: ' . $row['shipment_type'] . '<br />';

}






?>
</html>
