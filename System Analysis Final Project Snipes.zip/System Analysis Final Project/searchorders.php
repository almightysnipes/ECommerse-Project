<html>

<body>
 

<?php

session_start();
require_once "myfunctions.php";
myconnect();



   $studentid = $_REQUEST['orderid'];

   

$sql = "SELECT * FROM `orders` WHERE `orderid` LIKE '%$orderid'";
$queryResource = mysql_query($sql);

// Fetch rows from MySQL one at a time
while ($row = mysql_fetch_array($queryResource, MYSQL_ASSOC)) {
echo 'orderid: ' . $row['orderid'] . '<br />';
echo 'customerid: ' . $row['customerid'] . '<br />';
echo 'salesrepid: ' . $row['salesrepid'] . '<br />';
echo 'productid: ' . $row['productid'] . '<br />';
echo 'Quantity: ' . $row['quantity'] . '<br />';
echo 'Price: ' . $row['price'] . '<br />';
echo 'Date: ' . $row['date'] . '<br />';
echo 'Expected Deliery Date: ' . $row['expected_delivery_date'] . '<br />';
echo 'Actual Delivery Date: ' . $row['Actual_delivery_date'] . '<br />';
echo 'Delivery Type: ' . $row['Delivery_type'] . '<br />';
echo 'Name of Recipient: ' . $row['Name_f_Recipient'] . '<br />';

}






?>
</html>
