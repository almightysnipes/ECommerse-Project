<p>Update Product Form</p>

<?php
    session_start();
require_once "myfunctions.php";
myconnect();

   $productid = $_REQUEST['productid'];
   $code = $_REQUEST['code'];

   echo("product ID is ". $productid);
   echo("code is ".$code);


    $result = mysql_query("UPDATE `product` SET `productname` = '$productname' WHERE `productid` = '$productid'");

?>