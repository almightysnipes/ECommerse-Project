<p>Update Salesrep Form</p>

<?php
    session_start();
require_once "myfunctions.php";
myconnect();

   $salesrepid = $_REQUEST['salesrepid'];
   $phone = $_REQUEST['phone'];

   echo("salesrep ID is ". $salesrepid);
   echo("phone is ".$phone);


    $result = mysql_query("UPDATE `salesrep` SET `address` = '$address' WHERE `salesrepid` = '$salesrepid'");

?>