<html>
<body>


Results of Orders Database<br><br>

<?php
require_once "myfunctions.php";
myconnect();
  
   // retrieve all the rows from the database
   $query = "SELECT * FROM `orders` ORDER BY `customerid`";
   
   $results = mysql_query( $query );

   // print out the results
   if( $results )
   {
      while( $orders = mysql_fetch_object( $results ) )
      {
         // print out the info
         $customerid = $orders -> customerid;
         $Actual_delivery_date = $orders -> Actual_delivery_date;
         $Delivery_type = $orders -> Delivery_type;
         $Name_f_Recipient = $orders -> Name_f_Recipient;
         
         echo( "$customerid <br>, $Actual_delivery_date<br>, $Delivery_type<br>, $Name_f_Recipient<br><br><br>" );
      }
   }
   else
   {
      echo( "Trouble getting orders from database: ");
   }
   
?>

</body>
</html>
