 <?php
session_start();
require_once "myfunctions.php";
myconnect();
$email = $_REQUEST['email'];



echo "email:  ". $email;


$sql="SELECT userid FROM `login_tbl` WHERE `email`='$email'";
$r = mysql_query($sql); 
$count=mysql_affected_rows();
echo("$count\n");


if($count==1) 
{ 
while( $login_tbl = mysql_fetch_object( $r ) )
      {
         // print out the info
         $userid = $login_tbl -> userid;
        
         
         echo( "$userid <br><br><br>" );
      } 
// the message
echo "Please reset your passowrd at the following link
 <a href='resetpassword.html?userid=$userid'>Reset Password</a>";

// use wordwrap() if lines are longer than 70 characters
//$msg = wordwrap($msg,70);

// send email
//mail("$email","Reset Password Link",$msg);
}
else {
 echo "No Such email found: ";
}
?>

