<html>
<body>


Results of Product Database<br><br>

<?php
require_once "myfunctions.php";
myconnect();
  
   // retrieve all the rows from the database
   $query = "SELECT * FROM `product` ORDER BY `productname`";
   
   $results = mysql_query( $query );

   // print out the results
   if( $results )
   {
      while( $product = mysql_fetch_object( $results ) )
      {
         // print out the info
         $productid = $product -> productid;
         $productname = $product -> productname;
         $productdescription = $product -> productdescription;
         $code = $product -> code;
         
         echo( "$productid <br>, $productname<br>, $productdescription<br>, $code<br><br><br>" );
      }
   }
   else
   {
      echo( "Trouble getting products from database: ");
   }
   
?>

</body>
</html>
