
<?php
require_once "myfunctions.php";
myconnect();
    

   $shipmentid = $_REQUEST['shipmentid'];

echo "shipmentid = $shipmentid";


    $result = mysql_query("DELETE FROM shipments WHERE shipmentid = '$shipmentid'");
$count=mysql_affected_rows();
If ($count==1)
echo "Succesfully deleted";
else
{ 
echo "error deleting";
exit();
}

?>