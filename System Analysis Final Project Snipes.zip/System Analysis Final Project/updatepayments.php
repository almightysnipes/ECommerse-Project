<p>Update Payment Form</p>

<?php
    session_start();
require_once "myfunctions.php";
myconnect();

   $paymentid = $_REQUEST['paymentid'];
   $Payment_method = $_REQUEST['Payment_method'];

   echo("payment ID is ". $paymentid);
   echo("Payment method is ".$Payment_method);


    $result = mysql_query("UPDATE `payments` SET `payment_date` = '$payment_date' WHERE `paymentid` = '$paymentid'");

?>